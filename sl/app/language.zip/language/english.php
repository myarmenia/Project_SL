<?php
class English{
    //    for grid
    public $next = 'Next';
    public $edit = 'Edit';
    public $update = 'Update';
    public $cancel = 'Cancel';
    public $destroy = 'Delete';
    public $createNew = 'Add new record';
    public $name = 'Name';
    //    menu items
    public $open = 'Open';
    public $addTo = 'Add to';
    public $search = 'Search';
    public $dictionaries = 'Dictionaries';
    public $exit = 'Exit';
    //    man adding
    public $last_name = 'Last name';
    public $first_name = 'First name';
    public $middle_name = 'Middle name';
    public $also_known_as = 'Also known as';
    public $date_of_birth = 'Date of birth (day.month.year)';
    public $approximate_year = 'Approximate year of birth';
    public $passport_number = 'Passport number';
    public $gender = 'Gender';
    public $nationality = 'Nationality';
    public $citizenship = 'Citizenship';
    public $place_of_birth = 'Place of birth (country, ATU)';
    public $place_of_birth_area_local = 'Place of birth (area-local)';
    public $place_of_birth_settlement_local = 'Place of birth (settlement-local)';
    public $place_of_birth_area = 'Place of birth (area)';
    public $place_of_birth_settlement = 'Place of birth (settlement)';
    public $knowledge_of_languages = 'Knowledge of languages';


}